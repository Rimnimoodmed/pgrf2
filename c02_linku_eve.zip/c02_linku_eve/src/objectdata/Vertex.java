package objectdata;

import model.Vectorizable;
import transforms.Col;
import transforms.Mat4;
import transforms.Point3D;
import transforms.Vec2D;
import transforms.Vec3D;

public class Vertex implements Vectorizable<Vertex>{
    private Point3D position;
    private final Col color;
    private final Vec2D uv;
    //todo normal uv one
    public Vertex(Point3D position, Col color, Vec2D uv) {
        this.position = position;
        this.color = color;
        this.uv = uv;
    }
    
    public Point3D getPosition() {
        return position;
    }
    public Col getColor() {
        return color;
    }
    public double getX(){
        return position.getX();
    }
    public double getY(){
        return position.getY();
    }
    public double getZ(){
        return position.getZ();
    }
    public double getW(){
        return position.getW();
    }
    @Override
    public Vertex mul(double d) {
        return new Vertex(this.position.mul(d), this.color.mul(d), this.uv.mul(d));
    }

    @Override
    public Vertex add(Vertex v) {
        return new Vertex(this.position.add(v.getPosition()), this.color.add(v.getColor()), this.uv.add(v.getUv()));
    }

    public Vec2D getUv() {
        return uv;
    }

    public Vertex mul(Mat4 mat) {
        return new Vertex(this.position.mul(mat), this.color,this.uv);
    }

    public Vertex dehomog(Vertex v){
        v.position = new Point3D(v.position.dehomog().orElse(new Vec3D()));
        return v;
    }

    public void setPosition(Point3D position) {
        this.position = position;
    }
}
